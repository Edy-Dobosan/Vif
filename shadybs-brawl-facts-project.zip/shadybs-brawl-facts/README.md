# @shadybs — Brawl Stars Fun Facts

A 45-second, 1920×1080, 30fps Remotion video project. It includes an animated black-screen comeback intro, hook, five fact cards, outro, and persistent floating watermark.

## Setup

```bash
npx create-video@latest
```

Choose a TypeScript starter (or create a blank project), then replace/add the files in this folder with this project. Alternatively, use this folder directly:

```bash
npm install
npm start
```

The project uses `@remotion/google-fonts` to load **Lilita One** and **Roboto Mono**. An internet connection may be needed the first time the fonts are fetched.

## Render

```bash
npx remotion render src/index.ts BrawlFacts out/brawl-facts.mp4
```

Or use the package script:

```bash
npm run render
```

## Edit the facts

All five fact cards are defined in the `FACTS` array at the top of `src/Video.tsx`. Keep headlines to eight words or fewer and support copy to fifteen words or fewer for the intended layout.

## Timing

- 0–3s: Intro (90 frames)
- 3–6s: Hook (90 frames)
- 6–41s: Five facts (210 frames each)
- 41–45s: Outro (120 frames)
- Total: 1,350 frames

## Audio

Commented `<Audio>` placeholders are included in `src/Video.tsx`. Add your own licensed music and sound effects under `public/`, then uncomment/import `Audio` and `staticFile`.

## Notes

- All visuals are created from React shapes, text, CSS gradients, and emoji; no external image assets are required.
- The portrait-mode fact is phrased as an early-version development fact; verify/adjust copy to match your preferred source before publishing.
- The timeline uses continuously animated background elements, particles, text motion, and a persistent animated watermark.
