import React from 'react';
import {
  AbsoluteFill, Sequence, spring, interpolate, useCurrentFrame, useVideoConfig,
} from 'remotion';
import {loadFont as loadLilita} from '@remotion/google-fonts/LilitaOne';
import {loadFont as loadRobotoMono} from '@remotion/google-fonts/RobotoMono';

const {fontFamily: DISPLAY} = loadLilita();
const {fontFamily: MONO} = loadRobotoMono();

const C = {
  purple: '#8B35FF', yellow: '#FFE438', cyan: '#39F4FF',
  pink: '#FF3EA5', navy: '#10102C', black: '#030306', white: '#FFFFFF',
};

// Edit all on-screen fact copy here. Each headline is kept to eight words or fewer.
const FACTS = [
  {headline: "It's Supercell's 5th game!", support: 'Hay Day, Clash of Clans, Boom Beach, Clash Royale, then Brawl Stars.', icon: '🏆'},
  {headline: 'It was tested in Canada first!', support: 'Soft launch in 2017, worldwide release December 2018.', icon: '🍁'},
  {headline: 'It started as a portrait game!', support: 'Early versions used vertical gameplay before the shift to landscape.', icon: '📱'},
  {headline: 'Showdown was there from the start!', support: 'Gem Grab, Heist, Bounty, and Brawl Ball too.', icon: '💥'},
  {headline: 'Made in Finland!', support: 'Supercell is based in Helsinki.', icon: '🇫🇮'},
] as const;

const clamp = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};
const mix = (f: number, a: number, b: number) => interpolate(f, [a, b], [0, 1], clamp);

const Grain: React.FC<{opacity?: number}> = ({opacity = 0.12}) => (
  <AbsoluteFill style={{
    opacity, pointerEvents: 'none', mixBlendMode: 'screen',
    backgroundImage: 'repeating-radial-gradient(circle at 17% 31%, rgba(255,255,255,.7) 0 1px, transparent 1px 4px)',
    backgroundSize: '7px 7px',
  }}/>
);

const Particles: React.FC<{count?: number; dark?: boolean}> = ({count = 42, dark = false}) => {
  const frame = useCurrentFrame();
  return <AbsoluteFill style={{overflow: 'hidden', pointerEvents: 'none'}}>
    {Array.from({length: count}, (_, i) => {
      const x = (i * 137.5) % 100;
      const y = (i * 71.3) % 100;
      const drift = (frame * (0.12 + (i % 5) * 0.035) + i * 19) % 120;
      const twinkle = 0.25 + 0.75 * Math.abs(Math.sin(frame * 0.08 + i));
      return <div key={i} style={{
        position: 'absolute', left: `${x}%`, top: `${(y - drift + 120) % 100}%`,
        width: i % 7 === 0 ? 8 : 3 + (i % 3), height: i % 7 === 0 ? 8 : 3 + (i % 3),
        borderRadius: '50%', background: dark ? '#D7D2FF' : [C.yellow, C.cyan, C.pink, '#FFFFFF'][i % 4],
        opacity: twinkle * (dark ? 0.42 : 0.72), boxShadow: dark ? '0 0 10px #A99BFF' : '0 0 16px currentColor',
      }}/>;
    })}
  </AbsoluteFill>;
};

export const Watermark: React.FC = () => {
  const f = useCurrentFrame();
  const pulse = 0.84 + 0.12 * Math.sin(f / 13);
  return <div style={{
    position: 'absolute', right: 48, bottom: 30, zIndex: 100,
    color: 'white', opacity: 0.36, fontFamily: DISPLAY, fontSize: 32,
    transform: `translateY(${Math.sin(f / 19) * 5}px) scale(${pulse})`,
    textShadow: `3px 4px 0 ${C.purple}, 0 0 18px ${C.cyan}`,
    letterSpacing: 1,
  }}>@shadybs</div>;
};

export const AnimatedBackground: React.FC<{dark?: boolean}> = ({dark = false}) => {
  const f = useCurrentFrame();
  const turn = f * 0.22;
  const scale = 1.08 + 0.035 * Math.sin(f / 17);
  return <AbsoluteFill style={{
    overflow: 'hidden',
    background: dark ? '#030306' : `linear-gradient(${125 + Math.sin(f / 70) * 18}deg, #17103B 0%, #301078 42%, #101B48 100%)`,
  }}>
    {!dark && <>
      <div style={{position:'absolute', inset:-250, transform:`rotate(${turn}deg) scale(${scale})`,
        background:`radial-gradient(ellipse at ${30 + 12*Math.sin(f/35)}% ${40 + 15*Math.cos(f/41)}%, ${C.purple}99, transparent 34%), radial-gradient(ellipse at ${75 + 10*Math.cos(f/29)}% ${65 + 12*Math.sin(f/31)}%, ${C.cyan}55, transparent 30%), radial-gradient(ellipse at 50% 110%, ${C.pink}66, transparent 42%)`}}/>
      {Array.from({length: 7}, (_, i) => <div key={i} style={{
        position:'absolute', width:220 + (i%3)*95, height:220 + (i%3)*95,
        left:`${(i*23 + f*(i%2 ? .12 : -.08) + 120)%110 - 5}%`,
        top:`${(i*31 + Math.sin(f/24+i)*8)%105 - 3}%`,
        border:`${5 + i%4*3}px solid ${[C.yellow,C.cyan,C.pink,C.purple][i%4]}55`,
        borderRadius:i%2?'32%':'50%', transform:`rotate(${f*(i%2?0.35:-0.28)+i*27}deg)`,
        boxShadow:`0 0 35px ${[C.yellow,C.cyan,C.pink][i%3]}44`,
      }}/>)}
    </>}
    <Particles dark={dark} count={dark ? 55 : 58}/>
    {dark && <Grain opacity={0.17}/>}
    {!dark && <div style={{position:'absolute',inset:0,background:'radial-gradient(ellipse, transparent 45%, #050416AA 100%)'}}/>}
  </AbsoluteFill>;
};

const Outline: React.CSSProperties = {
  color: C.white, WebkitTextStroke: '3px #17102D',
  paintOrder: 'stroke fill', textShadow: '0 8px 0 #17102D, 0 13px 24px #0009',
  fontFamily: DISPLAY, fontWeight: 900, textAlign: 'center',
};

const Flash: React.FC<{at: number; duration?: number}> = ({at, duration = 10}) => {
  const f = useCurrentFrame();
  const opacity = interpolate(f, [at, at + 2, at + duration], [0, 1, 0], clamp);
  const scale = interpolate(f, [at, at + duration], [0.2, 2.8], clamp);
  return <AbsoluteFill style={{pointerEvents:'none', zIndex:80}}>
    <div style={{position:'absolute',inset:0,background:'#fff',opacity:opacity*0.94}}/>
    <div style={{position:'absolute',left:'50%',top:'50%',width:500,height:500,border:`18px solid ${C.cyan}`,
      borderRadius:'50%',transform:`translate(-50%,-50%) scale(${scale})`,opacity:opacity*0.8,
      boxShadow:`0 0 45px ${C.yellow}`}}/>
  </AbsoluteFill>;
};

export const Intro: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = spring({frame:f, fps, config:{damping:8, stiffness:180, mass:0.55}});
  const punch = interpolate(f,[72,75,83],[1,1.42,1.1],clamp);
  const shake = f > 72 && f < 90 ? Math.sin(f*2.8)*9 : Math.sin(f/8)*1.2;
  const visible = Math.min(7, Math.max(0, Math.floor((f-5)/7)+1));
  const title = "I'M BACK";
  const cursor = Math.floor(f/8)%2===0;
  const glow = f < 75 ? (Math.sin(f/5)+1)/2 : 1;
  const hue = interpolate(glow,[0,1],[270,52]);
  return <AbsoluteFill style={{background:C.black,overflow:'hidden'}}>
    <AnimatedBackground dark/>
    <div style={{position:'absolute',inset:0,background:`radial-gradient(ellipse at 50% 50%, transparent 15%, rgba(0,0,0,${0.56 + .12*Math.sin(f/12)}) 100%)`}}/>
    <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',
      transform:`translate(${shake}px,${-shake*.6}px) scale(${punch})`}}>
      <div style={{position:'relative',textAlign:'center'}}>
        <div style={{...Outline,fontFamily:MONO,fontSize:158,letterSpacing:7,whiteSpace:'nowrap',
          transform:`scale(${0.75+0.25*enter}) rotate(${Math.sin(f/6)*0.6}deg)`,
          textShadow:`${Math.sin(f*2)*3}px 0 ${C.pink}, ${-Math.sin(f*2)*3}px 0 ${C.cyan}, 0 0 ${22+glow*28}px hsl(${hue} 100% 60%), 0 10px 0 #21113D`,
          WebkitTextStroke:'2px #161020'}}>
          {title.slice(0,visible)}{cursor ? '▌' : ''}
        </div>
        <div style={{...Outline,fontFamily:MONO,fontSize:30,marginTop:22,letterSpacing:5,
          opacity:mix(f,24,36)*(0.45+0.55*Math.abs(Math.sin(f*1.7))),
          color:C.yellow,textShadow:`0 0 18px ${C.yellow}, 0 0 34px ${C.pink}`,
          transform:`translateX(${Math.sin(f*1.1)*4}px)`}}>...it's been a while</div>
      </div>
    </div>
    <div style={{position:'absolute',inset:0,opacity:0.08 + 0.08*Math.abs(Math.sin(f/3)),
      backgroundImage:'repeating-linear-gradient(0deg, transparent 0 5px, #fff 6px 7px)'}}/>
    <Flash at={76} duration={14}/>
  </AbsoluteFill>;
};

export const Hook: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame:f, fps, config:{damping:10, stiffness:140}});
  const shake = Math.sin(f*2.7)*Math.max(0,1-f/42)*9;
  return <AbsoluteFill style={{overflow:'hidden'}}>
    <AnimatedBackground/>
    <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',
      padding:120,transform:`translateX(${shake}px) scale(${0.65+0.35*s+0.025*Math.sin(f/3)}) rotate(${Math.sin(f/8)*1.2}deg)`}}>
      <div style={{...Outline,fontSize:104,lineHeight:1.12,maxWidth:1550}}>
        BRAWL STARS FACTS
        <div style={{color:C.yellow,fontSize:90,marginTop:18}}>YOU PROBABLY DIDN'T KNOW...</div>
      </div>
    </div>
    <Flash at={0} duration={9}/>
    <Flash at={78} duration={12}/>
  </AbsoluteFill>;
};

export const FactCard: React.FC<{fact: typeof FACTS[number]; index: number}> = ({fact,index}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = spring({frame:f, fps, config:{damping:11, stiffness:125, mass:0.8}});
  const exit = interpolate(f,[183,195],[1,0],clamp);
  const bob = Math.sin(f/8)*8;
  const rotate = Math.sin(f/10)*1.3;
  const accent = [C.yellow,C.cyan,C.pink,C.purple,'#8DFF8A'][index];
  return <AbsoluteFill style={{overflow:'hidden'}}>
    <AnimatedBackground/>
    <div style={{position:'absolute',left:150,top:135,width:1620,height:810,
      borderRadius:58,background:'linear-gradient(135deg,#19143DEB,#100E2CEB)',
      border:`8px solid ${accent}`,boxShadow:`0 0 45px ${accent}88, 0 24px 0 #08071B`,
      transform:`translateY(${(1-enter)*100 + bob}px) scale(${0.86+0.14*enter}) rotate(${rotate}deg)`,
      opacity:exit,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:70}}>
      <div style={{position:'absolute',top:38,left:48,width:126,height:126,borderRadius:32,
        background:accent,display:'flex',alignItems:'center',justifyContent:'center',
        transform:`rotate(${Math.sin(f/7)*8-8}deg) scale(${1+0.06*Math.sin(f/5)})`,
        color:C.navy,fontFamily:DISPLAY,fontSize:66,boxShadow:'0 9px 0 #090719'}}>
        {index+1}
      </div>
      <div style={{fontSize:112,marginBottom:18,transform:`translateY(${Math.sin(f/6)*5}px) rotate(${Math.sin(f/9)*4}deg)`}}>{fact.icon}</div>
      <div style={{...Outline,fontSize:82,lineHeight:1.12,maxWidth:1400,
        color:accent,transform:`scale(${1+0.012*Math.sin(f/6)})`}}>{fact.headline}</div>
      <div style={{...Outline,fontSize:39,lineHeight:1.35,maxWidth:1370,marginTop:34,
        WebkitTextStroke:'1.4px #17102D',color:'#FFFFFF'}}>{fact.support}</div>
      <div style={{position:'absolute',right:55,bottom:38,color:accent,fontFamily:MONO,fontSize:22,
        letterSpacing:4,opacity:.8 + .15*Math.sin(f/5)}}>FACT // 0{index+1}</div>
    </div>
    <div style={{position:'absolute',left:0,right:0,bottom:0,height:18,background:'#FFFFFF22'}}>
      <div style={{height:'100%',width:`${(f/210)*100}%`,background:accent,boxShadow:`0 0 20px ${accent}`}}/>
    </div>
  </AbsoluteFill>;
};

export const Outro: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame:f, fps, config:{damping:8, stiffness:120}});
  return <AbsoluteFill style={{overflow:'hidden'}}>
    <AnimatedBackground/>
    {Array.from({length:22},(_,i)=>{
      const a=i* Math.PI*2/22;
      const r=170+(f*2.4)%170;
      return <div key={i} style={{position:'absolute',left:'50%',top:'48%',
        width:i%3===0?22:12,height:i%3===0?22:12,
        background:[C.yellow,C.cyan,C.pink][i%3],borderRadius:i%2?'50%':'3px',
        transform:`translate(${Math.cos(a)*r}px,${Math.sin(a)*r}px) rotate(${f*4+i*23}deg)`,
        boxShadow:'0 0 20px currentColor'}}/>;
    })}
    <div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',
      alignItems:'center',justifyContent:'center',transform:`scale(${0.72+0.28*s+0.025*Math.sin(f/4)}) translateY(${Math.sin(f/5)*8}px)`}}>
      <div style={{...Outline,fontSize:150,color:C.yellow}}>FOLLOW FOR MORE!</div>
      <div style={{...Outline,fontSize:104,marginTop:28,color:C.cyan,
        textShadow:`0 8px 0 #17102D, 0 0 34px ${C.cyan}`}}>@shadybs</div>
      <div style={{fontSize:54,marginTop:34,transform:`rotate(${Math.sin(f/3)*12}deg) scale(${1+.12*Math.sin(f/3)})`}}>⭐ 💥 ⭐</div>
    </div>
  </AbsoluteFill>;
};

export const BrawlFacts: React.FC = () => (
  <AbsoluteFill style={{background:C.black}}>
    <Sequence from={0} durationInFrames={90}><Intro/></Sequence>
    <Sequence from={90} durationInFrames={90}><Hook/></Sequence>
    {FACTS.map((fact,i)=>(
      <Sequence key={i} from={180+i*210} durationInFrames={210}>
        <FactCard fact={fact} index={i}/>
      </Sequence>
    ))}
    <Sequence from={1230} durationInFrames={120}><Outro/></Sequence>
    <Watermark/>
    {/*
      AUDIO PLACEHOLDERS:
      <Audio src={staticFile('music.mp3')} volume={0.65} />
      Add short whoosh/hit clips at frame 0, 76, 90, every fact entrance,
      and frame 1230. Import Audio from 'remotion' and staticFile from 'remotion'
      when you add your own licensed audio assets.
    */}
  </AbsoluteFill>
);
