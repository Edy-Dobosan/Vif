import React from 'react';
import {Composition} from 'remotion';
import {BrawlFacts} from './Video';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="BrawlFacts"
    component={BrawlFacts}
    durationInFrames={1350}
    fps={30}
    width={1920}
    height={1080}
  />
);
