import React from 'react';
import {
  AbsoluteFill,
  Easing,
  Sequence,
  spring,
  interpolate,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {loadFont as loadAnton} from '@remotion/google-fonts/Anton';
import {loadFont as loadInter} from '@remotion/google-fonts/Inter';

const {fontFamily: anton} = loadAnton();
const {fontFamily: inter} = loadInter();

export const WIDTH = 1920;
export const HEIGHT = 1080;
export const FPS = 30;
export const INTRO_FRAMES = 60;
export const HOOK_FRAMES = 60;
export const FACT_DURATION = 120;
export const OUTRO_FRAMES = 90;
export const FACTS_START = INTRO_FRAMES + HOOK_FRAMES;
export const OUTRO_START = FACTS_START + 5 * FACT_DURATION;
export const DURATION_IN_FRAMES = INTRO_FRAMES + HOOK_FRAMES + 5 * FACT_DURATION + OUTRO_FRAMES;

const C = {
  ink: '#07090f',
  navy: '#0c1220',
  charcoal: '#111722',
  purple: '#302b52',
  blue: '#526b8a',
  gold: '#b79b62',
  white: '#f4f5f7',
  muted: '#a8b0bd',
};

type Fact = {headline: string; support: string; kicker: string};

// Keep all copy here so the edit is quick and safe.
export const FACTS: Fact[] = [
  {headline: "Supercell's 5th game!", support: 'After Hay Day, Clash of Clans, Boom Beach, Clash Royale.', kicker: 'THE STUDIO TIMELINE'},
  {headline: 'Tested in Canada first!', support: 'Soft launch 2017. Global release: December 2018.', kicker: 'FROM SOFT LAUNCH TO GLOBAL'},
  {headline: 'Everyone starts as Shelly!', support: 'The one brawler every new player gets.', kicker: 'YOUR FIRST BRAWLER'},
  {headline: 'Showdown was there day one!', support: 'Alongside Gem Grab, Heist, Bounty and Brawl Ball.', kicker: 'A CLASSIC MODE'},
  {headline: 'Made in Finland!', support: 'Supercell is based in Helsinki.', kicker: 'BUILT IN HELSINKI'},
];

const clamp = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};

const WordLine: React.FC<{text: string; start: number; size: number; color?: string; align?: 'left' | 'center'}> = ({
  text, start, size, color = C.white, align = 'center',
}) => {
  const frame = useCurrentFrame();
  const words = text.split(' ');
  return (
    <div style={{display: 'flex', flexWrap: 'wrap', justifyContent: align === 'center' ? 'center' : 'flex-start', gap: '0 0.24em'}}>
      {words.map((word, i) => {
        const local = frame - start - i * 3;
        const p = spring({frame: local, fps: 30, config: {damping: 17, stiffness: 230, mass: 0.65}});
        const opacity = interpolate(local, [0, 3, 8], [0, 1, 1], clamp);
        return <span key={`${word}-${i}`} style={{
          display: 'inline-block', opacity,
          transform: `translateY(${interpolate(p, [0, 1], [54, 0])}px) scale(${interpolate(p, [0, 1], [0.86, 1])})`,
          fontFamily: anton, fontSize: size, lineHeight: 0.98, letterSpacing: '0.015em',
        }}>{word}</span>;
      })}
    </div>
  );
};

export const AnimatedBackground: React.FC<{variant?: number; dark?: boolean}> = ({variant = 0, dark = false}) => {
  const frame = useCurrentFrame();
  const drift = frame * 0.22;
  const pulse = 0.5 + 0.5 * Math.sin(frame / 18);
  const particles = Array.from({length: 24}, (_, i) => ({
    x: (i * 173 + variant * 91) % WIDTH,
    y: (i * 97 + variant * 151) % HEIGHT,
    r: 1 + (i % 3),
    speed: 0.18 + (i % 5) * 0.055,
  }));
  return (
    <AbsoluteFill style={{overflow: 'hidden', background: dark
      ? 'radial-gradient(ellipse at 50% 46%, #171b2a 0%, #090c14 54%, #030407 100%)'
      : `radial-gradient(ellipse at ${48 + Math.sin(frame / 70 + variant) * 8}% ${42 + Math.cos(frame / 90) * 8}%, #25233e 0%, #111927 48%, #070a11 100%)`}}>
      <div style={{position: 'absolute', inset: -80, transform: `translate(${Math.sin(frame / 44) * 18}px, ${Math.cos(frame / 52) * 14}px) scale(${1.05 + pulse * 0.012})`,
        background: 'linear-gradient(115deg, transparent 25%, rgba(82,107,138,.12) 48%, transparent 68%)'}} />
      <div style={{position: 'absolute', width: 980, height: 980, border: '1px solid rgba(183,155,98,.12)', borderRadius: '50%',
        left: '50%', top: '50%', transform: `translate(-50%,-50%) scale(${0.82 + pulse * 0.04})`}} />
      <div style={{position: 'absolute', width: 1320, height: 1320, border: '1px solid rgba(130,151,179,.08)', borderRadius: '50%',
        left: '50%', top: '50%', transform: `translate(-50%,-50%) rotate(${frame * 0.025}deg)`}} />
      {particles.map((p, i) => <div key={i} style={{
        position: 'absolute', left: p.x, top: (p.y + drift * p.speed) % HEIGHT,
        width: p.r, height: p.r, borderRadius: '50%', background: i % 5 === 0 ? C.gold : '#c6d0df',
        opacity: 0.12 + 0.16 * (0.5 + 0.5 * Math.sin(frame / 11 + i)), filter: 'blur(.4px)',
      }} />)}
      <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at center, transparent 35%, rgba(0,0,0,.62) 100%)'}} />
      {/* Fine film grain: SVG turbulence keeps the texture procedural and asset-free. */}
      <svg width="100%" height="100%" style={{position: 'absolute', inset: 0, opacity: dark ? 0.075 : 0.045, mixBlendMode: 'soft-light'}}>
        <filter id={`grain-${variant}`}><feTurbulence type="fractalNoise" baseFrequency="0.82" numOctaves="2" stitchTiles="stitch"/></filter>
        <rect width="100%" height="100%" filter={`url(#grain-${variant})`} opacity="0.55"/>
      </svg>
    </AbsoluteFill>
  );
};

export const Watermark: React.FC = () => {
  const f = useCurrentFrame();
  const opacity = 0.32 + 0.045 * Math.sin(f / 24);
  return <div style={{position: 'absolute', right: 64, bottom: 42, zIndex: 50, color: C.white, opacity,
    fontFamily: inter, fontWeight: 700, fontSize: 23, letterSpacing: '0.12em',
    transform: `translateY(${Math.sin(f / 32) * 3}px)`}}> @shadybs </div>;
};

const Intro: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const punch = spring({frame: frame - 48, fps, config: {damping: 12, stiffness: 320, mass: 0.5}});
  const shake = frame >= 48 && frame <= 56 ? Math.sin(frame * 2.7) * (56 - frame) * 1.8 : 0;
  const letters = "I'M BACK".split('');
  return (
    <AbsoluteFill style={{background: '#020203', justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
      <AnimatedBackground dark />
      <div style={{position: 'absolute', inset: 0, background: `radial-gradient(circle, transparent 20%, rgba(0,0,0,${0.42 + 0.06 * Math.sin(frame / 8)}) 100%)`}}/>
      <div style={{display: 'flex', gap: 18, transform: `translateX(${shake}px) scale(${frame >= 48 ? 1 + punch * 0.16 : 1})`, zIndex: 2}}>
        {letters.map((letter, i) => {
          const local = frame - 7 - i * 3;
          const p = spring({frame: local, fps, config: {damping: 14, stiffness: 280, mass: 0.55}});
          const op = interpolate(local, [0, 3], [0, 1], clamp);
          return <span key={i} style={{fontFamily: anton, color: C.white, fontSize: 176, letterSpacing: '0.055em', opacity: op,
            transform: `translateY(${interpolate(p, [0, 1], [70, 0])}px) scale(${interpolate(p, [0, 1], [0.7, 1])})`,
            textShadow: '3px 0 rgba(82,107,138,.45), -2px 0 rgba(183,155,98,.22)'}}>{letter === ' ' ? '\u00a0' : letter}</span>;
        })}
      </div>
      {frame >= 24 && <div style={{position: 'absolute', top: '61%', color: '#aeb6c3', fontFamily: 'monospace',
        fontSize: 25, letterSpacing: '0.24em', opacity: interpolate(Math.sin(frame * 1.4), [-1, 1], [0.35, 0.9]),
        transform: `translateY(${interpolate(frame, [24, 34], [12, 0], clamp)}px)`}}>...it's been a while</div>}
      {frame >= 48 && <AbsoluteFill style={{background: '#fff', opacity: interpolate(frame, [48, 50, 53, 58], [0, 0.95, 0.24, 0], clamp)}}/>}
      <div style={{position: 'absolute', width: 300, height: 300, border: '2px solid rgba(183,155,98,.55)', borderRadius: '50%',
        transform: `scale(${interpolate(frame, [48, 58], [0.2, 5.5], clamp)})`, opacity: interpolate(frame, [48, 51, 58], [0, 0.65, 0], clamp)}}/>
    </AbsoluteFill>
  );
};

const Hook: React.FC = () => {
  const frame = useCurrentFrame();
  const zoom = spring({frame: frame - 48, fps: 30, config: {damping: 14, stiffness: 260}});
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
      <AnimatedBackground variant={1}/>
      <div style={{position: 'absolute', left: -220, top: 0, width: 560, height: '100%', background: 'linear-gradient(90deg, transparent, rgba(82,107,138,.15), transparent)',
        transform: `translateX(${frame * 16}px) skewX(-18deg)`}}/>
      <div style={{zIndex: 2, width: 1500, textAlign: 'center', transform: `scale(${frame >= 48 ? 1 + zoom * 0.08 : 1 + frame * 0.001})`}}>
        <div style={{fontFamily: inter, fontSize: 24, letterSpacing: '0.42em', color: C.gold, marginBottom: 34}}>A QUICK RETURN</div>
        <WordLine text="BRAWL STARS FACTS" start={3} size={118}/>
        <div style={{height: 24}}/>
        <WordLine text="YOU PROBABLY DIDN'T KNOW..." start={17} size={62} color="#c5ceda"/>
      </div>
      <div style={{position: 'absolute', bottom: 105, width: 420, height: 2, background: C.gold, transform: `scaleX(${interpolate(frame, [4, 28], [0, 1], clamp)})`, transformOrigin: 'center'}}/>
    </AbsoluteFill>
  );
};

const FactCard: React.FC<{fact: Fact; index: number}> = ({fact, index}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = spring({frame, fps, config: {damping: 16, stiffness: 250, mass: 0.65}});
  const support = spring({frame: frame - 12, fps, config: {damping: 18, stiffness: 210}});
  const exit = interpolate(frame, [108, 119], [0, 1], clamp);
  const slide = index % 2 === 0 ? -1 : 1;
  const impact = frame < 8 ? Math.sin(frame * 2.4) * (8 - frame) * 0.9 : 0;
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
      <AnimatedBackground variant={index + 2}/>
      <div style={{position: 'absolute', width: 1140, height: 1, background: 'rgba(183,155,98,.38)', top: 235,
        transform: `translateX(${interpolate(frame, [0, 22], [-360, 0], clamp)}px)`}}/>
      <div style={{position: 'absolute', left: 230, top: 240, fontFamily: inter, fontSize: 22, letterSpacing: '0.34em', color: C.gold,
        opacity: interpolate(frame, [0, 7], [0, 1], clamp)}}>{fact.kicker}</div>
      <div style={{position: 'absolute', top: 300, left: 220, display: 'flex', alignItems: 'center', gap: 26,
        transform: `translateX(${slide * (1 - enter) * 130 + impact}px) scale(${interpolate(enter, [0, 1], [0.9, 1])})`,
        opacity: interpolate(frame, [0, 3], [0, 1], clamp) * (1 - exit)}}>
        <div style={{width: 94, height: 94, border: `2px solid ${C.gold}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: C.gold, fontFamily: anton, fontSize: 48, background: 'rgba(8,12,20,.62)'}}>{String(index + 1).padStart(2, '0')}</div>
        <div style={{width: 3, height: 90, background: C.gold, opacity: 0.75}}/>
        <div style={{fontFamily: inter, fontSize: 22, letterSpacing: '0.22em', color: '#9eabbc'}}>BRAWL STARS / FIELD NOTES</div>
      </div>
      <div style={{position: 'absolute', left: 220, right: 180, top: 440, opacity: 1 - exit,
        transform: `translateX(${slide * (1 - enter) * 190}px) scale(${interpolate(enter, [0, 1], [0.88, 1])})`}}>
        <div style={{fontFamily: anton, fontSize: 112, lineHeight: 1.03, letterSpacing: '0.012em', color: C.white,
          textShadow: '0 12px 45px rgba(0,0,0,.35)'}}>{fact.headline}</div>
        <div style={{height: 28}}/>
        <div style={{height: 3, width: interpolate(support, [0, 1], [0, 310]), background: C.gold, marginBottom: 25}}/>
        <div style={{fontFamily: inter, fontSize: 35, lineHeight: 1.3, fontWeight: 500, color: '#c2cad5',
          opacity: interpolate(frame, [12, 19], [0, 1], clamp),
          transform: `translateY(${interpolate(support, [0, 1], [22, 0])}px)`}}>{fact.support}</div>
      </div>
      <div style={{position: 'absolute', right: 0, top: 0, width: 520, height: '100%',
        background: 'linear-gradient(90deg, transparent, rgba(82,107,138,.09))',
        transform: `translateX(${Math.sin(frame / 19) * 28}px)`}}/>
      <div style={{position: 'absolute', bottom: 100, left: 220, right: 220, height: 1, background: 'rgba(174,188,208,.18)'}}>
        <div style={{height: '100%', width: `${Math.min(100, frame / FACT_DURATION * 100)}%`, background: C.gold}}/>
      </div>
    </AbsoluteFill>
  );
};

const Outro: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: frame - 8, fps, config: {damping: 14, stiffness: 260}});
  const zoomOut = interpolate(frame, [68, 89], [1, 0.74], clamp);
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
      <AnimatedBackground variant={9}/>
      <div style={{position: 'absolute', left: -400, top: '49%', width: 2800, height: 3,
        background: 'linear-gradient(90deg, transparent, rgba(183,155,98,.9), rgba(210,220,235,.5), transparent)',
        transform: `translateX(${interpolate(frame, [4, 28], [-800, 1000], clamp)}px) rotate(-8deg)`, filter: 'blur(1px)'}}/>
      <div style={{zIndex: 2, textAlign: 'center', transform: `scale(${interpolate(p, [0, 1], [0.78, 1]) * zoomOut})`}}>
        <div style={{fontFamily: anton, fontSize: 142, letterSpacing: '0.035em', color: C.white}}>FOLLOW FOR MORE</div>
        <div style={{height: 24}}/>
        <div style={{fontFamily: inter, fontWeight: 700, fontSize: 42, letterSpacing: '0.28em', color: C.gold}}>@SHADYBS</div>
        <div style={{width: 340, height: 2, background: C.gold, margin: '38px auto 0',
          transform: `scaleX(${interpolate(frame, [18, 34], [0, 1], clamp)})`}}/>
      </div>
      <div style={{position: 'absolute', inset: 0, background: '#fff', opacity: interpolate(frame, [0, 2, 5], [0.8, 0.12, 0], clamp)}}/>
    </AbsoluteFill>
  );
};

const TransitionHits: React.FC = () => {
  const frame = useCurrentFrame();
  const boundaries = [60, 120, 240, 360, 480, 600, 720];
  return <AbsoluteFill style={{pointerEvents: 'none', zIndex: 40}}>
    {boundaries.map((at) => {
      const local = frame - at;
      const opacity = interpolate(local, [-4, 0, 2, 7], [0, 0.7, 0.22, 0], clamp);
      const scale = interpolate(local, [-3, 7], [0.7, 1.35], clamp);
      return <React.Fragment key={at}>
        <div style={{position: 'absolute', inset: 0, background: '#e9edf4', opacity}}/>
        <div style={{position: 'absolute', top: 0, bottom: 0, left: '50%', width: 5, background: C.gold,
          opacity: opacity * 0.8, transform: `translateX(-50%) scaleY(${scale})`}}/>
      </React.Fragment>;
    })}
  </AbsoluteFill>;
};

export const BrawlStarsFacts: React.FC = () => {
  return (
    <AbsoluteFill style={{background: C.ink, color: C.white}}>
      <Sequence from={0} durationInFrames={INTRO_FRAMES}><Intro/></Sequence>
      <Sequence from={INTRO_FRAMES} durationInFrames={HOOK_FRAMES}><Hook/></Sequence>
      {FACTS.map((fact, i) => (
        <Sequence key={fact.headline} from={FACTS_START + i * FACT_DURATION} durationInFrames={FACT_DURATION}>
          <FactCard fact={fact} index={i}/>
        </Sequence>
      ))}
      <Sequence from={OUTRO_START} durationInFrames={OUTRO_FRAMES}><Outro/></Sequence>
      <TransitionHits/>
      <Watermark/>
      {/*
        AUDIO PLACEHOLDERS — add licensed files with staticFile() when supplied:
        <Audio src={staticFile('audio/cinematic-bed.wav')} volume={0.22} />
        <Sequence from={48} durationInFrames={12}><Audio src={staticFile('audio/impact.wav')} /></Sequence>
        <Sequence from={60} durationInFrames={12}><Audio src={staticFile('audio/whoosh.wav')} /></Sequence>
        Repeat short whoosh/impact hits at frames 120, 240, 360, 480, 600, and 720.
      */}
    </AbsoluteFill>
  );
};