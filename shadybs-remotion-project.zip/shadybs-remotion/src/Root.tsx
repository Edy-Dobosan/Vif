import React from 'react';
import {Composition} from 'remotion';
import {BrawlStarsFacts, DURATION_IN_FRAMES, FPS, HEIGHT, WIDTH} from './Video';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="BrawlStarsFacts"
      component={BrawlStarsFacts}
      durationInFrames={DURATION_IN_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  );
};