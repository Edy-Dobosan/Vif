# @shadybs — Brawl Stars Facts

A 27-second, 1920×1080 Remotion composition at 30fps (810 frames). The project uses React + TypeScript, `spring()`, `interpolate()`, `<Composition>`, and `<Sequence>`.

## Setup

```bash
npx create-video@latest
```

Choose a TypeScript starter, then replace/add the files in this folder (or use this folder as the project root). Install dependencies:

```bash
npm install
npm start
```

Remotion Studio opens with the `BrawlStarsFacts` composition.

## Render

```bash
npx remotion render src/index.ts BrawlStarsFacts out/shadybs-brawl-stars-facts.mp4
```

## Edit points

- All five facts are in `FACTS` at the top of `src/Video.tsx`.
- Change `FACT_DURATION` to retime each fact; the composition duration is derived from the timeline constants.
- The timeline is 60f intro + 60f hook + 5×120f facts + 90f outro = 810 frames.
- Palette, type, watermark, background particles, transitions, and scene components are centralized in `src/Video.tsx`.

## Audio / voice

Audio components are left as commented placeholders. Add licensed music and SFX under `public/audio/`, then uncomment/import `Audio` and `staticFile`. No ElevenLabs key is needed for this visual-only build. If a voiceover is added later, use a natural conversational delivery; a 1.2× speed/pitch target can be applied in the voice-generation workflow if supported by that provider.

## Fact note

The wording follows the supplied brief. Before publishing, verify historical game-mode launch timing and any copy you want to present as a precise “day one” claim.
